
'use strict';
const AWS = require('aws-sdk');
const error = require('./lib/error.js');
const docClient = new AWS.DynamoDB.DocumentClient({region: process.env.AWS_REGION});
const sqs = new AWS.SQS();
const sns = new AWS.SNS({region: process.env.AWS_REGION});

exports.handler = (event, context, callback) => {
  console.log('Received event:', JSON.stringify(event, null, 2));
  const msgAttrs = event.Records[0].messageAttributes;

  //let messageId = event.Records[0].messageId;

  var deleteParams = {
    QueueUrl: process.env.QueueURL,
    ReceiptHandle: event.Records[0].receiptHandle
  };

  if (('guid' in msgAttrs) && ('newVideoName' in msgAttrs) && ('origVideoName' in msgAttrs)) {

    let guid = event.Records[0].messageAttributes.guid.stringValue;
    let newVideoName = event.Records[0].messageAttributes.newVideoName.stringValue;

    const stepfunctions = new AWS.StepFunctions({
      region: process.env.AWS_REGION
    });

    let input = {
      guid: guid,
      origVideoName: event.Records[0].messageAttributes.origVideoName.stringValue,
      newVideoName: newVideoName,
      workflowStatus: "upload",      
    };

    let dbparams = {
      TableName: process.env.DynamoDBTable,
      Key: {
          guid: guid,
      },
         // remove the trailing ',' from the update expression added by the forEach loop
      UpdateExpression: 'set newVideoName = :na',
      ExpressionAttributeValues: { ":na": newVideoName }
    };
     
    console.log('Dynamo update -> New Video Name: ', JSON.stringify(dbparams, null, 2));

    docClient.update(dbparams).promise()
    .then(() => {
        console.log('Successfully updated');
    })
    .catch(err => {
        console.log('Unable to update DB', JSON.stringify(err, null, 2));  
        //error.handler(event, err);
        //callback(err);
    });

    let params = {
      stateMachineArn: process.env.UploadWorkflow,
      input: JSON.stringify(input),
      name: guid
    };

    console.log('workflow execute: ', JSON.stringify(input, null, 2));

    stepfunctions.startExecution(params).promise()
    .then(() => callback(null, 'success'))
    .catch(err => {
      event.guid = guid;
      sqs.deleteMessage(deleteParams, function(err, data) {
       if (err) {
         console.log("Message Delete Error", err);
       } else {
         console.log("Message Deleted", data);
       }
     });         
      error.handler(event, err);
      callback(err);
    });
  } else {
   console.log('Insufficient Arguments');
   console.log('Sending Notification');
   let params = {
      Message: 'Insufficient Arguments to SQS message :' + JSON.stringify(event, null, 2),
      Subject: ' Insufficient Arguments ',
      TargetArn: process.env.NotificationSns
    };
    sns.publish(params).promise()
    .then(() => {
      console.log('Notification successfully sent');
      callback(null, 'Success');
    })
    .catch(() => {
      console.log('Error while sending notification');
      callback(null, 'Error');
    });
   sqs.deleteMessage(deleteParams, function(err, data) {
      if (err) {
         console.log("Message Delete Error", err);
      } else {
         console.log("Message Deleted", data);
      }
    });         
 }
};