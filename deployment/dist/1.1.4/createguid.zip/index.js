'use strict';
const AWS = require('aws-sdk');
const uuid = require('uuid');

exports.handler = (event, context, callback) => {
  console.log('Received event:', JSON.stringify(event, null, 2));

  let key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, " "));
  let guid = uuid.v4();

  console.log('Vide File Name: ', key);
  console.log('GUID: ', guid);
  
  
  const docClient = new AWS.DynamoDB.DocumentClient({
         region: process.env.AWS_REGION
  });

  let params = {
     TableName: process.env.DynamoDBTable,
     Key: {
         guid: guid,
     },
     // remove the trailing ',' from the update expression added by the forEach loop
    UpdateExpression: "set origVideoName = :n, workflowStatus = :s",
    ExpressionAttributeValues:{
        ":n":key,
        ":s":"received",
    }
  };

 console.log('Dynamo update: ', JSON.stringify(params, null, 2));

 docClient.update(params).promise()
   .then(() => {
       event.guid = guid;
       callback(null, event);
   })

   .catch(err => {
       console.log('Failed to update database');
       console.log(err);
       callback(err);
   });

};
